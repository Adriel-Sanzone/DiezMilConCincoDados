public class Casa {
}
