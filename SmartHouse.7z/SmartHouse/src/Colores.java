public enum Colores {
    BLANCO, ROJO, AZUL, VERDE
}
